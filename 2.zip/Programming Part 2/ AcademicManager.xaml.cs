using System.Windows;

namespace ClaimManagement
{
    public partial class AcademicManager : Window
    {
        public AcademicManager()
        {
            InitializeComponent();
        }

        private void LoadPendingClaims_Click(object sender, RoutedEventArgs e)
        {
            DisplayPendingClaims();
        }

        private void ApproveClaim_Click(object sender, RoutedEventArgs e)
        {
            // Logic for approving a claim
        }

        private void RejectClaim_Click(object sender, RoutedEventArgs e)
        {
            // Logic for rejecting a claim
        }

        private void DisplayPendingClaims()
        {
            var pendingClaims = ClaimsDataModel.Instance.GetPendingClaims();
            claimsDataGrid.ItemsSource = pendingClaims;
        }
    }
}
