using System.Linq;
using System.Windows;

namespace ClaimManagement
{
    public partial class CoordinatorManagerView : Window
    {
        public CoordinatorManagerView()
        {
            InitializeComponent();
            DisplayClaims();
        }

        // Displays all claims in the data grid
        private void DisplayClaims()
        {
            var claims = ClaimsDataModel.Instance.ClaimList;  // Use ClaimList property
            claimsDataGrid.ItemsSource = claims;  // Ensure claimsDataGrid is correctly referenced
        }

        // Approve button click handler
        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            if (claimsDataGrid.SelectedItem is Claim selectedClaim)
            {
                selectedClaim.Status = "Approved";
                MessageBox.Show($"Claim {selectedClaim.ClaimID} has been approved.");
            }
        }

        // Reject button click handler
        private void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            if (claimsDataGrid.SelectedItem is Claim selectedClaim)
            {
                selectedClaim.Status = "Rejected";
                MessageBox.Show($"Claim {selectedClaim.ClaimID} has been rejected.");
            }
        }
    }
}
