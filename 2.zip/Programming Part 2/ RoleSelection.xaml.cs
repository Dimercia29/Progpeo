using System.Windows;

namespace ClaimManagement
{
	public partial class RoleSelection : Window
	{
		public RoleSelection()
		{
			InitializeComponent();
		}

		// Navigate to Program Coordinator Dashboard
		private void ProgramCoordinatorButton_Click(object sender, RoutedEventArgs e)
		{
			ProgramCoordinator programCoordinator = new ProgramCoordinator();
			programCoordinator.Show();
			this.Close();
		}

		// Navigate to Academic Manager Dashboard
		private void AcademicManagerButton_Click(object sender, RoutedEventArgs e)
		{
			AcademicManager academicManager = new AcademicManager();
			academicManager.Show();
			this.Close();
		}
	}
}
