﻿namespace ClaimManagement
{
    public class Claim
    {
        public int ClaimID { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string HoursWorked { get; set; }
        public string HourlyRate { get; set; }
        public string AdditionalNotes { get; set; }
        public string SupportingDocument { get; set; }
        public string Status { get; set; }

        // Primary constructor for simplification
        public Claim(int claimId, string firstName, string surname, string hoursWorked, string hourlyRate, string additionalNotes, string supportingDocument, string status) =>
            (ClaimID, FirstName, Surname, HoursWorked, HourlyRate, AdditionalNotes, SupportingDocument, Status) =
            (claimId, firstName, surname, hoursWorked, hourlyRate, additionalNotes, supportingDocument, status);
    }
}
