﻿using System.Collections.ObjectModel;
using System.Linq;

namespace ClaimManagement
{
    public class ClaimsDataModel
    {
        private static readonly ClaimsDataModel _instance = new ClaimsDataModel();
        public static ClaimsDataModel Instance => _instance;

        public ObservableCollection<Claim> ClaimList { get; set; } = new ObservableCollection<Claim>();

        private ClaimsDataModel() { }

        public ObservableCollection<Claim> GetPendingClaims()
        {
            return new ObservableCollection<Claim>(ClaimList.Where(c => c.Status == "Pending"));
        }
    }
}
