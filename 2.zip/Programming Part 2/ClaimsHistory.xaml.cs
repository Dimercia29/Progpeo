﻿using System.Windows;
using System.Windows.Controls;

namespace ClaimManagement
{
    public partial class ClaimsHistory : Window
    {
        public ClaimsHistory()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
