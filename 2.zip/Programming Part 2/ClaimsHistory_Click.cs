﻿namespace ClaimManagement
{
    internal class ClaimsHistory_Click
    {
    }
}