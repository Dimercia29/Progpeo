﻿using System;
using System.Windows;
using Microsoft.Win32;

namespace ClaimManagement
{
    public partial class LecturerDashboard : Window
    {
        public LecturerDashboard()
        {
            InitializeComponent();
        }

        private void InputFields_TextChanged(object sender, RoutedEventArgs e)
        {
            if (decimal.TryParse(hoursWorkedTextBox.Text, out decimal hours) &&
                decimal.TryParse(hourlyRateTextBox.Text, out decimal rate))
            {
                paymentTextBlock.Text = $"Final Payment: ${(hours * rate):F2}";
            }
            else
            {
                paymentTextBlock.Text = "Invalid Input";
            }
        }

        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "PDF files (*.pdf)|*.pdf|Word Documents (*.docx)|*.docx|Excel Files (*.xlsx)|*.xlsx"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                uploadedFileNameTextBlock.Text = $"Uploaded: {System.IO.Path.GetFileName(openFileDialog.FileName)}";
            }
        }

        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(nameTextBox.Text) ||
                string.IsNullOrWhiteSpace(surnameTextBox.Text) ||
                string.IsNullOrWhiteSpace(hoursWorkedTextBox.Text) ||
                string.IsNullOrWhiteSpace(hourlyRateTextBox.Text))
            {
                MessageBox.Show("Please fill out all fields before submitting.");
                return;
            }

            MessageBox.Show("Claim successfully submitted.");
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
