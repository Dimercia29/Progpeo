﻿using System.Windows;

namespace ClaimManagement
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LecturerDashboard_Click(object sender, RoutedEventArgs e)
        {
            LecturerDashboard lecturerDashboard = new LecturerDashboard();
            lecturerDashboard.Show();
            this.Close();
        }

        private void ClaimsHistory_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claims History View is not implemented yet.");
        }

        private void CoordinatorManagerView_Click(object sender, RoutedEventArgs e)
        {
            CoordinatorManagerView coordinatorView = new CoordinatorManagerView();
            coordinatorView.Show();
            this.Close();
        }
    }
}
