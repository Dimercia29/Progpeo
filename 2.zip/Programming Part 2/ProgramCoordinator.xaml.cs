using System.Windows;

namespace ClaimManagement
{
    public partial class ProgramCoordinator : Window
    {
        public ProgramCoordinator()
        {
            InitializeComponent();
        }

        private void LoadPendingClaims_Click(object sender, RoutedEventArgs e)
        {
            DisplayPendingClaims();
        }

        private void ApproveClaim_Click(object sender, RoutedEventArgs e)
        {
            // Implement your logic to approve claims
        }

        private void RejectClaim_Click(object sender, RoutedEventArgs e)
        {
            // Implement your logic to reject claims
        }

        private void DisplayPendingClaims()
        {
            var pendingClaims = ClaimsDataModel.Instance.GetPendingClaims();
            claimsDataGrid.ItemsSource = pendingClaims;
        }
    }
}
